package com.cts.project.trainReservation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.project.trainReservation.model.TrainDetails;

public interface TrainDetailsRepository extends JpaRepository<TrainDetails, Integer>{

}
