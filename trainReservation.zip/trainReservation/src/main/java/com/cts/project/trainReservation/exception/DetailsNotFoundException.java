package com.cts.project.trainReservation.exception;


public class DetailsNotFoundException extends RuntimeException {
	
	public DetailsNotFoundException(String message) {
		super(message);
	}
}
