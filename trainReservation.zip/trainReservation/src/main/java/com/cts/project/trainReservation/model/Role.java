package com.cts.project.trainReservation.model;

public enum Role {
	USER,
	ADMIN
}
